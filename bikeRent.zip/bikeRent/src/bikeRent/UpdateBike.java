package bikeRent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import java.awt.Color;

public class UpdateBike extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textName;
	private JTextField textNumber;
	private JTextField textCharges;
	
	private JComboBox cmb = new JComboBox();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		UpdateBike d=new UpdateBike();
		d.setVisible(true);
		d.pack();
		
	}

	
	
	public void load()
	{
		
		try
		{
			cmb.removeAllItems();
		}
		catch(Exception e)
		{

		}
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
				Statement st = conn.createStatement();
				ResultSet rs=st.executeQuery("select name,number from bike where status=1");
				int n=0;
				while(rs.next())
					n++;
				String name[]=new String[n];
				String number[]=new String[n];
				String list[]=new String[n];
				
				rs.beforeFirst();
				rs.next();
				for(int i=0;i<n;i++)
				{
					name[i]=rs.getString(1);
					number[i]=rs.getString(2);
					
					list[i]=name[i]+" / "+number[i];
					cmb.addItem(list[i]);
					rs.next();
				}
		
				
				
				cmb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
			
				int i=(int)cmb.getSelectedIndex();
				textName.setText(name[i]);
				textNumber.setText(number[i]);
				
				
				
					try
					{
					ResultSet rs=st.executeQuery("select chargeperkm from bike where name='"+textName.getText()+"' and number='"+textNumber.getText()+"'");
					rs.next();
					textCharges.setText(rs.getString(1));
					}
					catch(Exception ex)
					{
					JOptionPane.showMessageDialog(null, "error");
					}
				
				
				
					}	
				}); 
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
		
	
	}
	/**
	 * Create the frame.
	 */
	public UpdateBike() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
			AdminMain am=new AdminMain();
			am.setVisible(true);
			am.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 542, 356);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDeleteBike = new JLabel("Update / Delete Bike...");
		lblDeleteBike.setForeground(Color.BLUE);
		lblDeleteBike.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDeleteBike.setBounds(26, 27, 205, 20);
		contentPane.add(lblDeleteBike);
		
		JLabel lblSelect = new JLabel("Select:");
		lblSelect.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSelect.setBounds(36, 73, 62, 21);
		contentPane.add(lblSelect);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblName.setBounds(33, 127, 54, 20);
		contentPane.add(lblName);
		
		JLabel lblNumber = new JLabel("Number:");
		lblNumber.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNumber.setBounds(26, 173, 68, 14);
		contentPane.add(lblNumber);
		
		JLabel lblCharges = new JLabel("Charges:");
		lblCharges.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCharges.setBounds(26, 216, 75, 20);
		contentPane.add(lblCharges);
		
		textName = new JTextField();
		textName.setBounds(115, 127, 155, 23);
		contentPane.add(textName);
		textName.setColumns(10);
		
		textNumber = new JTextField();
		textNumber.setBounds(116, 172, 154, 23);
		contentPane.add(textNumber);
		textNumber.setColumns(10);
		
		textCharges = new JTextField();
		textCharges.setBounds(119, 218, 147, 23);
		contentPane.add(textCharges);
		textCharges.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setForeground(new Color(255, 255, 255));
		btnDelete.setBackground(new Color(153, 102, 255));
		btnDelete.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try
				{
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
				Statement st=conn.createStatement();
				int i=st.executeUpdate("delete from bike where name='"+textName.getText()+"' and number='"+textNumber.getText()+"'");
				if(i==1)
					JOptionPane.showMessageDialog(null, "Deleted Succesfull");
				dispose();	
					
				
				}
				catch(Exception eee)
				{
					JOptionPane.showMessageDialog(null, "error into deleting");
				}
				
				load();
			}
		});
		btnDelete.setBounds(205, 256, 107, 35);
		contentPane.add(btnDelete);
		
		
		
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setForeground(new Color(255, 255, 255));
		btnUpdate.setBackground(new Color(153, 102, 255));
		btnUpdate.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			String chr=textCharges.getText();
			Boolean b=false;
			
			if(chr.length()!=0)
			{
				for(int i=0;i<chr.length();i++)
				{
					if(Character.isAlphabetic(chr.charAt(i)))
					{
						b=false;
						break;
					}
					else
					{
						b=true;
					}
				}
			}
				
			if(b==true)
			{
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
				PreparedStatement st = conn.prepareStatement("update bike set chargeperkm='"+textCharges.getText()+"' where name='"+textName.getText()+"' and number='"+textNumber.getText()+"'");
				int i=st.executeUpdate();
				if(i!=0)
					JOptionPane.showMessageDialog(null, "update successful");
				dispose();
				
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null, "Error");
			}
			load();
			}
			else
			{
				JOptionPane.showMessageDialog(null, "something wrong");
			}
			}
		});
		btnUpdate.setBounds(36, 256, 121, 35);
		contentPane.add(btnUpdate);
		cmb.setBounds(115, 74, 189, 23);
		contentPane.add(cmb);
		
		JLabel label = new JLabel("");
		java.awt.Image imglogo=new ImageIcon(this.getClass().getResource("/delete.png")).getImage();
		label.setIcon(new ImageIcon(imglogo));
		label.setBounds(356, 90, 147, 172);
		contentPane.add(label);
		load();
	}
}
	