package bikeRent;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JPasswordField;

public class AdminRegistration extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textUserName;
	private JTextField textAnswer;
	private JComboBox comboBox = new JComboBox();
	private JPasswordField textPass;
	private JPasswordField textConfirmPass;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminRegistration frame = new AdminRegistration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminRegistration() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 480, 352);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("UserName:");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUsername.setBounds(69, 52, 79, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPassword.setBounds(75, 101, 73, 14);
		contentPane.add(lblPassword);
		
		JLabel lblConfirmPassword = new JLabel("Confirm Password:");
		lblConfirmPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblConfirmPassword.setBounds(10, 144, 138, 14);
		contentPane.add(lblConfirmPassword);
		
		JLabel lblSecurityQuestion = new JLabel("Security Question:");
		lblSecurityQuestion.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSecurityQuestion.setBounds(10, 192, 138, 14);
		contentPane.add(lblSecurityQuestion);
		
		JLabel lblAnswer = new JLabel("Answer:");
		lblAnswer.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAnswer.setBounds(84, 228, 64, 14);
		contentPane.add(lblAnswer);
		
		textUserName = new JTextField();
		textUserName.setBounds(169, 51, 119, 20);
		contentPane.add(textUserName);
		textUserName.setColumns(10);
		
		textAnswer = new JTextField();
		textAnswer.setBounds(169, 227, 119, 20);
		contentPane.add(textAnswer);
		textAnswer.setColumns(10);
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Question", "Your Mother's Name", "Your First English Teacher", "Your First Pet", "Your Childhood Name"}));
		
		
		comboBox.setBounds(169, 183, 206, 33);
		contentPane.add(comboBox);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBackground(new Color(153, 102, 255));
		btnRegister.setForeground(Color.WHITE);
		btnRegister.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
				if(textUserName.getText().length()!=0 && textPass.getText().length()>=4 && textConfirmPass.getText().length()>=4 && textAnswer.getText().length()!=0)
				{
					if(textPass.getText().equals(textConfirmPass.getText()))
					{
						if(comboBox.getSelectedIndex()!=0)
						{
							try
							{
							Class.forName("com.mysql.jdbc.Driver");
							Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
							PreparedStatement st=conn.prepareStatement("insert into admintable values(?,?,?,?)");
							st.setString(1, textUserName.getText());
							st.setString(2, textPass.getText());
							st.setString(3, (String)comboBox.getSelectedItem());
							st.setString(4, textAnswer.getText());
							int i=st.executeUpdate();
								if(i!=0)
								{
									JOptionPane.showMessageDialog(null, "Rcord Entered Successfully");
								dispose();
									Front fr=new Front();
								fr.frame.setVisible(true);
								
								}
								else
									JOptionPane.showMessageDialog(null, "Error into Entering Record");
								
							
									
							}
							catch(Exception e)
							{
								JOptionPane.showMessageDialog(null, e);
							}
						}
						else
						{
							JOptionPane.showMessageDialog(null, "choose a security question");
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "password mis matched");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "enter all details");
				}
			
			
			}
		});
		btnRegister.setBounds(311, 255, 119, 33);
		contentPane.add(btnRegister);
		
		JLabel lblAdminRegistration = new JLabel("Admin Registration");
		lblAdminRegistration.setForeground(Color.BLUE);
		lblAdminRegistration.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAdminRegistration.setBounds(26, 11, 193, 25);
		contentPane.add(lblAdminRegistration);
		
		JLabel label = new JLabel("");
		java.awt.Image imglogo=new ImageIcon(this.getClass().getResource("/adminiregister.png")).getImage();
		label.setIcon(new ImageIcon(imglogo));
		label.setBounds(316, 27, 138, 149);
		contentPane.add(label);
		
		textPass = new JPasswordField();
		textPass.setBounds(169, 100, 137, 20);
		contentPane.add(textPass);
		
		textConfirmPass = new JPasswordField();
		textConfirmPass.setBounds(169, 143, 137, 20);
		contentPane.add(textConfirmPass);
	}
}
