package bikeRent;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ChangePassword extends JFrame {

	private JPanel contentPane;
	private JPasswordField textOldPass;
	private JPasswordField textNewPass;
	private JPasswordField textConfirmNewPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePassword frame = new ChangePassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChangePassword() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
			AdminMain ad=new AdminMain();
			ad.setVisible(true);
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 602, 323);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblChangePassword = new JLabel("Change Password...");
		lblChangePassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangePassword.setForeground(Color.BLUE);
		lblChangePassword.setBounds(29, 27, 185, 25);
		contentPane.add(lblChangePassword);
		
		JLabel lblOldPassword = new JLabel("Old Password:");
		lblOldPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblOldPassword.setBounds(87, 85, 103, 14);
		contentPane.add(lblOldPassword);
		
		JLabel lblNewPassword = new JLabel("New Password:");
		lblNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewPassword.setBounds(81, 129, 109, 14);
		contentPane.add(lblNewPassword);
		
		JLabel lblConfirmNewPassword = new JLabel("Confirm new Password:");
		lblConfirmNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblConfirmNewPassword.setBounds(21, 180, 169, 14);
		contentPane.add(lblConfirmNewPassword);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			String oldpass=textOldPass.getText();
			String newpass=textNewPass.getText();
			String confirmnewpass=textConfirmNewPass.getText();
			if(newpass.length()>=4 && confirmnewpass.length()>=4)
			{
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","root");
					Statement st = conn.createStatement();
					ResultSet rs=st.executeQuery("select password from admintable");
					rs.next();
					String s1=rs.getString(1);
					if(s1.equals(oldpass))
					{
						if(newpass.equals(confirmnewpass))
						{
							PreparedStatement st1 = conn.prepareStatement("update admintable set password='"+newpass+"'");
							int i=st1.executeUpdate();
							if(i!=0)
								JOptionPane.showMessageDialog(null, "Password changed");
							dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "new password not matched");
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "old password did not matched");
					}
			}
			catch(Exception e)
			{
				
			}
			}
			else
				JOptionPane.showMessageDialog(null, "password should be more than 4 character");
			}
			
			
		});
		btnChangePassword.setForeground(new Color(255, 255, 255));
		btnChangePassword.setBackground(new Color(153, 102, 255));
		btnChangePassword.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnChangePassword.setBounds(205, 226, 161, 35);
		contentPane.add(btnChangePassword);
		
		JLabel label = new JLabel("");
		java.awt.Image imglogo=new ImageIcon(this.getClass().getResource("/changepass.png")).getImage();
		label.setIcon(new ImageIcon(imglogo));
		label.setBounds(397, 85, 128, 143);
		contentPane.add(label);
		
		textOldPass = new JPasswordField();
		textOldPass.setBounds(200, 82, 161, 25);
		contentPane.add(textOldPass);
		
		textNewPass = new JPasswordField();
		textNewPass.setBounds(200, 126, 164, 25);
		contentPane.add(textNewPass);
		
		textConfirmNewPass = new JPasswordField();
		textConfirmNewPass.setBounds(200, 177, 166, 25);
		contentPane.add(textConfirmNewPass);
	}
}
