package bikeRent;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.event.*;
import java.sql.*;
import java.sql.Date;
import java.util.*;

public class AdminMain extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textUserName;
	private JTextField textPhone;
	private JTextField textMail;
	private JTextField textAddress;
	private JTextField textName;
	private JTextField textNumber;
	private JTextField textCharges;
	private JTextField textHour;
	private JPanel panel2;
	private JPanel panel3;
	private JTextField textUserNameReturn;
	private JTextField textAddressReturn;
	private JTextField textPhoneReturn;
	private JTextField textMailReturn;
	private JTextField textBikeNameReturn;
	private JTextField textNumberReturn;
	private JTextField textChargesReturn;
	private JTextField textExpectedHoursReturn;
	private JTextField textExtraHoursReturn;
	private JComboBox cmb1 = new JComboBox();
	private JComboBox cmb2 = new JComboBox();
	private JTextField textTotalReturn;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		AdminMain ad=new AdminMain();
		ad.setVisible(true);
		
	}

	
	public void loadavailablebike()
	{
		try {
			cmb1.removeAllItems();
		}
		catch(Exception e)
		{
			
		}
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
				Statement st = conn.createStatement();
				ResultSet rs=st.executeQuery("select name,number from bike where status=1");
				int n=0;
				while(rs.next())
					n++;
				
				String name[]=new String[n];
				String number[]=new String[n];
				String list[]=new String[n];
				
				rs.beforeFirst();
				rs.next();
				for(int i=0;i<n;i++)
				{
					name[i]=rs.getString(1);
					number[i]=rs.getString(2);
					list[i]=name[i]+" / "+number[i];
					rs.next();
					cmb1.addItem(list[i]);
				}
		
		
				
				cmb1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
			
				int i=(int)cmb1.getSelectedIndex();
				textName.setText(name[i]);
				textNumber.setText(number[i]);
				
				
				
					try
					{
					ResultSet rs=st.executeQuery("select chargeperkm from bike where name='"+textName.getText()+"' and number='"+textNumber.getText()+"'");
					rs.next();
					textCharges.setText(rs.getString(1));
					}
					catch(Exception ex)
					{
					
					}
				
				
				
					}	
				});
		}
		catch(Exception e)
		{
			
		}
		
		
	}
	
	
	public void loadrentbike()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
				Statement st = conn.createStatement();
				ResultSet rs=st.executeQuery("select bikename,bikenumber number from bikeonrent");
				int n=0;
				while(rs.next())
					n++;
				
				String name[]=new String[n];
				String number[]=new String[n];
				String list[]=new String[n];
				
				rs.beforeFirst();
				rs.next();
				for(int i=0;i<n;i++)
				{
					name[i]=rs.getString(1);
					number[i]=rs.getString(2);
					list[i]=name[i]+" / "+number[i];
					rs.next();
					cmb2.addItem(list[i]);
				}
		
		
				
				cmb2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
			
				int i=cmb2.getSelectedIndex();
				
					try
					{
						
					ResultSet rs=st.executeQuery("select date,username,useraddress,userphone,useremail,chargesperkm,expectedhour,amount from bikeonrent where bikename='"+name[i]+"' and bikenumber='"+number[i]+"'");
					rs.next();
					
					Date olddate=rs.getDate(1);
					textUserNameReturn.setText(rs.getString(2));
					textAddressReturn.setText(rs.getString(3));
					textPhoneReturn.setText(rs.getString(4));
					textMailReturn.setText(rs.getString(5));
					textBikeNameReturn.setText(name[i]);
					textNumberReturn.setText(number[i]);
					textChargesReturn.setText(rs.getString(6));
					textExpectedHoursReturn.setText(rs.getString(7));
					textTotalReturn.setText(rs.getString(8));
					}
					catch(Exception ex)
					{
						JOptionPane.showMessageDialog(null, ex);
					}
				
				
				
					}	
				});
		}
		catch(Exception e)
		{
			
		}
		
	}
		
	
	
	
	/**
	 * Create the frame.
	 */
	public AdminMain() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
			
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1061, 683);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JButton btnHistory = new JButton("History");
		java.awt.Image imglogo3=new ImageIcon(this.getClass().getResource("/history.png")).getImage();
		btnHistory.setIcon(new ImageIcon(imglogo3));
		btnHistory.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnHistory.setBackground(new Color(255, 255, 255));
		btnHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				try {
					Historytable ht=new Historytable();
					ht.setVisible(true);
					ht.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "error");
				}
			
			}
		});
		btnHistory.setBounds(879, 61, 141, 33);
		contentPane.add(btnHistory);
		
		JButton btnAllBikes = new JButton("All Bikes");
		java.awt.Image imglogo12=new ImageIcon(this.getClass().getResource("/all.png")).getImage();
		btnAllBikes.setIcon(new ImageIcon(imglogo12));
		btnAllBikes.setForeground(Color.BLACK);
		btnAllBikes.setBackground(Color.WHITE);
		btnAllBikes.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnAllBikes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				try {
					Allbike al=new Allbike();
					al.setVisible(true);
					al.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "error");
				}
			
			}
		});
		btnAllBikes.setBounds(651, 17, 141, 33);
		contentPane.add(btnAllBikes);
		
		JButton btnOnRrent = new JButton("On Rent");
		btnOnRrent.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnOnRrent.setForeground(Color.BLACK);
		btnOnRrent.setBackground(Color.WHITE);
		java.awt.Image imglogo11=new ImageIcon(this.getClass().getResource("/onrent.png")).getImage();
		btnOnRrent.setIcon(new ImageIcon(imglogo11));
		btnOnRrent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				try {
					Onrentbike orb=new Onrentbike();
					orb.setVisible(true);
					orb.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "error");
				}
			
			}
		});
		btnOnRrent.setBounds(496, 61, 145, 33);
		contentPane.add(btnOnRrent);
		
		JButton btnAvailable = new JButton("Available");
		btnAvailable.setBackground(Color.WHITE);
		btnAvailable.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		java.awt.Image imglogo8=new ImageIcon(this.getClass().getResource("/available.png")).getImage();
		btnAvailable.setIcon(new ImageIcon(imglogo8));
		btnAvailable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				try {
					Availablebike av=new Availablebike();
					av.setVisible(true);
					av.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "error");
				}
				
			}
		});
		btnAvailable.setBounds(496, 17, 145, 33);
		contentPane.add(btnAvailable);
		
		JButton btnAddBike = new JButton("Add Bike");
		java.awt.Image imglogo6=new ImageIcon(this.getClass().getResource("/add.png")).getImage();
		btnAddBike.setIcon(new ImageIcon(imglogo6));
		btnAddBike.setBackground(Color.WHITE);
		btnAddBike.setForeground(Color.BLACK);
		btnAddBike.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnAddBike.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			dispose();
				Addbike ab=new Addbike();
			ab.setVisible(true);
			ab.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		});
		btnAddBike.setBounds(350, 17, 136, 33);
		contentPane.add(btnAddBike);
		
		JButton btnDeleteBike = new JButton("Update");
		java.awt.Image imglogo7=new ImageIcon(this.getClass().getResource("/update.png")).getImage();
		btnDeleteBike.setIcon(new ImageIcon(imglogo7));
		btnDeleteBike.setForeground(Color.BLACK);
		btnDeleteBike.setBackground(Color.WHITE);
		btnDeleteBike.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnDeleteBike.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			dispose();
				UpdateBike ub=new UpdateBike();
			ub.setVisible(true);
			ub.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		});
		btnDeleteBike.setBounds(350, 61, 136, 33);
		contentPane.add(btnDeleteBike);
		
		
		
		panel3 = new JPanel();
		panel3.setBackground(Color.WHITE);
		panel3.setBounds(44, 116, 597, 506);
		contentPane.add(panel3);
		panel3.setLayout(null);
		panel3.setVisible(false);
		
		JLabel lblSelect_1 = new JLabel("Select:");
		lblSelect_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSelect_1.setBounds(58, 66, 53, 14);
		panel3.add(lblSelect_1);
		
		JLabel lblName_2 = new JLabel("User Name:");
		lblName_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblName_2.setBounds(25, 115, 92, 14);
		panel3.add(lblName_2);
		
		JLabel lblAddress_1 = new JLabel("Address:");
		lblAddress_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAddress_1.setBounds(35, 150, 69, 14);
		panel3.add(lblAddress_1);
		
		JLabel lblBikeName = new JLabel("Bike Name:");
		lblBikeName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblBikeName.setBounds(323, 115, 92, 14);
		panel3.add(lblBikeName);
		
		JLabel lblBikeNumber = new JLabel("Bike NUmber:");
		lblBikeNumber.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblBikeNumber.setBounds(305, 150, 99, 14);
		panel3.add(lblBikeNumber);
		
		JLabel lblCharges_1 = new JLabel("Charges:");
		lblCharges_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCharges_1.setBounds(335, 181, 69, 21);
		panel3.add(lblCharges_1);
		
		JLabel lblPhone_1 = new JLabel("Phone:");
		lblPhone_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPhone_1.setBounds(48, 184, 69, 14);
		panel3.add(lblPhone_1);
		
		JLabel lblMail = new JLabel("Mail:");
		lblMail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMail.setBounds(68, 218, 34, 14);
		panel3.add(lblMail);
		
		JLabel lblExpectedHours = new JLabel("Expected Hours:");
		lblExpectedHours.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblExpectedHours.setBounds(283, 218, 121, 14);
		panel3.add(lblExpectedHours);
		
		JLabel lblExtraHours = new JLabel("Extra hours:");
		lblExtraHours.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblExtraHours.setBounds(25, 336, 92, 14);
		panel3.add(lblExtraHours);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.WHITE);
		panel1.setForeground(Color.BLACK);
		panel1.setBounds(44, 116, 453, 368);
		contentPane.add(panel1);
		panel1.setLayout(null);
		
		JButton btnReturn = new JButton("Return");
		btnReturn.setBackground(new Color(153, 102, 255));
		btnReturn.setForeground(Color.WHITE);
		btnReturn.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				if(textUserNameReturn.getText().length()!=0 && textBikeNameReturn.getText().length()!=0)
				{
					int extrahour=Integer.parseInt(textExtraHoursReturn.getText());
					int chrgperhour=Integer.parseInt(textChargesReturn.getText());
					int oldtotal=Integer.parseInt(textTotalReturn.getText());
					int totalhrs=Integer.parseInt(textExpectedHoursReturn.getText())+extrahour;
					double finalchrg=oldtotal+(chrgperhour*1.5*extrahour)-1000;
					JOptionPane.showMessageDialog(null, textUserName.getText()+"\n"+textAddressReturn.getText()+"\n"+
							textPhoneReturn.getText()+"\n"+textMailReturn.getText()+"\n"+textAddressReturn.getText()+"\n"+
							totalhrs+"\n"+finalchrg);
					Calendar calendar=Calendar.getInstance();
					java.sql.Date todaydate= new java.sql.Date(calendar.getTime().getTime());
					try
					{
						
						Class.forName("com.mysql.jdbc.Driver");
						Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
						
						
						
						PreparedStatement st=conn.prepareStatement("insert into history values(?,?,?,?,?,?,?,?,?)");
						st.setDate(1, todaydate);
						st.setString(2, textUserNameReturn.getText());
						st.setString(3, textAddressReturn.getText());
						st.setString(4, textPhoneReturn.getText());
						st.setString(5, textMailReturn.getText());
						st.setString(6, textBikeNameReturn.getText());
						st.setString(7, textNumberReturn.getText());
						st.setString(8, ""+totalhrs);
						st.setString(9, ""+finalchrg);
						st.executeUpdate();
						//JOptionPane.showMessageDialog(null, "history me chle gaya");
						
						st=conn.prepareStatement("update bike set status=1 where name='"+textBikeNameReturn.getText()+"' and number='"+textNumberReturn.getText()+"'");
						st.executeUpdate();
						//JOptionPane.showMessageDialog(null, "bike status change ho gya");
						
						 st=conn.prepareStatement("delete from bikeonrent where bikename='"+textBikeNameReturn.getText()+"' and bikenumber='"+textNumberReturn.getText()+"'");
						 st.executeUpdate();
						// JOptionPane.showMessageDialog(null, "bikeonrent se delete ho gya");
				
						 st=conn.prepareStatement("delete from user where username='"+textUserNameReturn.getText()+"' ");
						 st.executeUpdate();
						// JOptionPane.showMessageDialog(null, "bikeonrent se delete ho gya");
						 panel3.setVisible(false);
						 panel1.setVisible(true);
						 
					}
					catch(Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
					//SendEmail.sendemail(textUserName.getText(),textName.getText(),textNumber.getText(),exphour,chrgs,total,security,grandtotal,textMail.getText());
					
					
				}
				else
					JOptionPane.showMessageDialog(null, "enter expected hours");
			
			
			loadavailablebike();
			}
		});
		btnReturn.setEnabled(false);
		btnReturn.setBounds(170, 459, 137, 27);
		panel3.add(btnReturn);
		
		JButton btnCalculateAmount = new JButton("Calculate Amount");
		btnCalculateAmount.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnCalculateAmount.setForeground(Color.WHITE);
		btnCalculateAmount.setBackground(new Color(153, 102, 255));
		btnCalculateAmount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
		if(textUserNameReturn.getText().length()!=0 && textBikeNameReturn.getText().length()!=0)
		{
			int extrahour=Integer.parseInt(textExtraHoursReturn.getText());
			int chrgperhour=Integer.parseInt(textChargesReturn.getText());
			int oldtotal=Integer.parseInt(textTotalReturn.getText());
			double finalchrg=oldtotal+(chrgperhour*1.5*extrahour);
			JOptionPane.showMessageDialog(null, "Old total: "+oldtotal+"\nExtra Hours: "+extrahour+"\nSecurity Amount: -1000"+"\n\nNew total amount: "+(finalchrg-1000));
			btnReturn.setEnabled(true);
		}
		else
			JOptionPane.showMessageDialog(null, "select bike to return");
			
			}
		});
		btnCalculateAmount.setBounds(170, 378, 137, 27);
		panel3.add(btnCalculateAmount);
		
		JLabel lblTotalAmount = new JLabel("Total Amount:");
		lblTotalAmount.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTotalAmount.setBounds(25, 422, 114, 14);
		panel3.add(lblTotalAmount);
		
		
		textUserNameReturn = new JTextField();
		textUserNameReturn.setBounds(122, 114, 137, 23);
		panel3.add(textUserNameReturn);
		textUserNameReturn.setColumns(10);
		
		textAddressReturn = new JTextField();
		textAddressReturn.setBounds(122, 148, 137, 23);
		panel3.add(textAddressReturn);
		textAddressReturn.setColumns(10);
		
		textPhoneReturn = new JTextField();
		textPhoneReturn.setBounds(122, 182, 137, 23);
		panel3.add(textPhoneReturn);
		textPhoneReturn.setColumns(10);
		
		textMailReturn = new JTextField();
		textMailReturn.setBounds(122, 216, 137, 23);
		panel3.add(textMailReturn);
		textMailReturn.setColumns(10);
		
		textBikeNameReturn = new JTextField();
		textBikeNameReturn.setBounds(428, 114, 137, 23);
		panel3.add(textBikeNameReturn);
		textBikeNameReturn.setColumns(10);
		
		textNumberReturn = new JTextField();
		textNumberReturn.setBounds(428, 149, 137, 22);
		panel3.add(textNumberReturn);
		textNumberReturn.setColumns(10);
		
		textChargesReturn = new JTextField();
		textChargesReturn.setBounds(428, 183, 137, 22);
		panel3.add(textChargesReturn);
		textChargesReturn.setColumns(10);
		
		textExpectedHoursReturn = new JTextField();
		textExpectedHoursReturn.setBounds(428, 217, 137, 23);
		panel3.add(textExpectedHoursReturn);
		textExpectedHoursReturn.setColumns(10);
		
		textExtraHoursReturn = new JTextField();
		textExtraHoursReturn.setText("0");
		textExtraHoursReturn.setBounds(127, 335, 132, 23);
		panel3.add(textExtraHoursReturn);
		textExtraHoursReturn.setColumns(10);
		
		
		
		cmb2.setBounds(122, 62, 221, 27);
		panel3.add(cmb2);
		
		JLabel lblTotal = new JLabel("Total:");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTotal.setBounds(71, 300, 46, 14);
		panel3.add(lblTotal);
		
		textTotalReturn = new JTextField();
		textTotalReturn.setBounds(122, 299, 137, 23);
		panel3.add(textTotalReturn);
		textTotalReturn.setColumns(10);
		
		JLabel lblReturnbike = new JLabel("Return Bike...");
		lblReturnbike.setForeground(Color.BLUE);
		lblReturnbike.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReturnbike.setBounds(48, 28, 129, 23);
		panel3.add(lblReturnbike);
		
		JLabel label_1 = new JLabel("");
		java.awt.Image imglogo=new ImageIcon(this.getClass().getResource("/return1.png")).getImage();
		label_1.setIcon(new ImageIcon(imglogo));
		label_1.setBounds(335, 289, 238, 184);
		panel3.add(label_1);
		
		JButton btnLogOut = new JButton("Log out");
		btnLogOut.setBackground(new Color(255, 255, 255));
		btnLogOut.setForeground(new Color(0, 0, 0));
		btnLogOut.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		java.awt.Image imglogo2=new ImageIcon(this.getClass().getResource("/logout.png")).getImage();
		btnLogOut.setIcon(new ImageIcon(imglogo2));
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			dispose();
			Front front=new Front();
			front.frame.setVisible(true);
					}
		});
		btnLogOut.setBounds(879, 17, 143, 33);
		contentPane.add(btnLogOut);
		
		JButton btnReturn_1 = new JButton("Return");
		java.awt.Image imglogo10=new ImageIcon(this.getClass().getResource("/return.png")).getImage();
		btnReturn_1.setIcon(new ImageIcon(imglogo10));
		btnReturn_1.setForeground(Color.BLACK);
		btnReturn_1.setBackground(Color.WHITE);
		btnReturn_1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		btnReturn_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				panel3.setVisible(true);
				panel1.setVisible(false);
				panel2.setVisible(false);
				
			loadrentbike();
			}
		});
		btnReturn_1.setBounds(651, 61, 141, 33);
		contentPane.add(btnReturn_1);
		//java.awt.Image img=new ImageIcon(this.getClass().getResource("/abc.jpg")).getImage();
		
		
		
		
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblName.setBounds(32, 80, 47, 25);
		panel1.add(lblName);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAddress.setBounds(21, 131, 72, 14);
		panel1.add(lblAddress);
		
		JLabel lblPhone = new JLabel("Phone:");
		lblPhone.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPhone.setBounds(32, 227, 61, 14);
		panel1.add(lblPhone);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEmail.setBounds(36, 269, 46, 14);
		panel1.add(lblEmail);
		
		textUserName = new JTextField();
		textUserName.setBounds(105, 84, 162, 21);
		panel1.add(textUserName);
		textUserName.setColumns(10);
		
		textPhone = new JTextField();
		textPhone.setBounds(105, 226, 162, 25);
		panel1.add(textPhone);
		textPhone.setColumns(10);
		
		textMail = new JTextField();
		textMail.setBounds(105, 268, 162, 25);
		panel1.add(textMail);
		textMail.setColumns(10);
		
		textAddress = new JTextField();
		textAddress.setBounds(103, 128, 162, 74);
		panel1.add(textAddress);
		textAddress.setColumns(10);
		
		JButton btnNext = new JButton("Next");
		btnNext.setBackground(new Color(153, 102, 255));
		btnNext.setForeground(Color.WHITE);
		btnNext.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			String username=textUserName.getText();
			String address=textAddress.getText();
			String phone=textPhone.getText();
			String mail=textMail.getText();
			Boolean name=false;
			Boolean add=false;
			Boolean ph=false;
			Boolean m=false;
			
			if(username.length()!=0)
			{
			for(int i=0;i<username.length();i++)
			{
				if(Character.isDigit(username.charAt(i)))
				{
					name=false;
					break;
				}
				else
				{
					name=true;
				}
			}
			}
			
			if(address.length()>=3)
			{
				add=true;
			}
			
			if(phone.length()==10)
			{
			for(int i=0;i<phone.length();i++)
			{
				if(Character.isAlphabetic(phone.charAt(i)))
				{
					ph=false;
					break;
				}
				else
				{
					ph=true;
				}
			}
			}
			
			if(mail.length()!=0)
			{
				int at=0;
				int dot=0 ;
				int l=mail.length();
				for(int i=0;i<l;i++)
				{
					if(mail.charAt(i)=='@')
						at=i;
					if(mail.charAt(i)=='.')
						dot=i;
				}
				if(at>0 && at<dot && dot==l-4 && dot>at+1)
				{
					m=true;
				}
			}
				
			if(name==true && add==true && ph==true && m==true)
				{
			panel1.setVisible(false);
			panel2.setVisible(true);
			loadavailablebike();
				}
			else
				JOptionPane.showMessageDialog(null, "enter correct detail");
			}
		});
		btnNext.setBounds(323, 306, 100, 34);
		panel1.add(btnNext);
		
		JLabel lblEnterDetails = new JLabel("Enter Details...");
		lblEnterDetails.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEnterDetails.setForeground(Color.BLUE);
		lblEnterDetails.setBounds(32, 26, 171, 20);
		panel1.add(lblEnterDetails);
		
		JLabel label = new JLabel("");
		java.awt.Image imglogo1=new ImageIcon(this.getClass().getResource("/enterdetail.png")).getImage();
		label.setIcon(new ImageIcon(imglogo1));
		label.setBounds(306, 114, 128, 148);
		panel1.add(label);
		
		panel2 = new JPanel();
		panel2.setBounds(44, 116, 453, 368);
		contentPane.add(panel2);
		panel2.setBackground(Color.WHITE);
		panel2.setLayout(null);
		panel2.setVisible(false);
		
		
		
		JLabel lblSelectBike = new JLabel("Select Bike...");
		lblSelectBike.setForeground(Color.BLUE);
		lblSelectBike.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSelectBike.setBounds(34, 24, 148, 23);
		panel2.add(lblSelectBike);
		
		JLabel lblSelect = new JLabel("Select:");
		lblSelect.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSelect.setBounds(34, 77, 53, 14);
		panel2.add(lblSelect);
		
		
		JLabel lblName_1 = new JLabel("Name:");
		lblName_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblName_1.setBounds(34, 119, 64, 14);
		panel2.add(lblName_1);
		
		JLabel lblNumber = new JLabel("Number:");
		lblNumber.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNumber.setBounds(23, 162, 64, 14);
		panel2.add(lblNumber);
		
		JLabel lblCharges = new JLabel("Charges:");
		lblCharges.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCharges.setBounds(23, 207, 64, 19);
		panel2.add(lblCharges);
		
		JLabel lblEnterExpectedHours = new JLabel("Enter expected hours:");
		lblEnterExpectedHours.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEnterExpectedHours.setBounds(23, 249, 164, 14);
		panel2.add(lblEnterExpectedHours);
		
		textName = new JTextField();
		textName.setBounds(112, 117, 184, 23);
		panel2.add(textName);
		textName.setColumns(10);
		
		textNumber = new JTextField();
		textNumber.setBounds(112, 160, 184, 23);
		panel2.add(textNumber);
		textNumber.setColumns(10);
		
		textCharges = new JTextField();
		textCharges.setBounds(112, 208, 107, 23);
		panel2.add(textCharges);
		textCharges.setColumns(10);
		
		textHour = new JTextField();
		textHour.setBounds(122, 283, 97, 23);
		panel2.add(textHour);
		textHour.setColumns(10);
		
		
		
		JButton btnBook = new JButton("Book");
		btnBook.setForeground(Color.WHITE);
		btnBook.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnBook.setBackground(new Color(153, 102, 255));
		btnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				Boolean b=false;
				String hr=textHour.getText();
				if(hr.length()>0)
				{
				for(int i=0;i<hr.length();i++)
				{
					if(Character.isAlphabetic(hr.charAt(i)))
					{
						b=false;
						break;
					}
					else
					{
						b=true;
					}
				}
				}
			if(b==true && textName.getText().length()!=0)
			{
				int exphour=Integer.parseInt(textHour.getText());
				int chrgs=Integer.parseInt(textCharges.getText());
				int total=exphour*chrgs;
				int security=1000;
				int grandtotal=total+security;
				JOptionPane.showMessageDialog(null, "Bike selected: "+textName.getText()+"\nBike's per km Charge: "+
				textCharges.getText()+"\nHours: "+textHour.getText()+"\nSecurity amount: 1000\nTotal amount: "+(total+1000));
				
				try
				{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
					PreparedStatement st=conn.prepareStatement("insert into user values(null,?,?,?,?)");
					st.setString(1,textUserName.getText() );
					st.setString(2,textAddress.getText() );
					st.setString(3,textPhone.getText() );
					st.setString(4,textMail.getText() );
					st.executeUpdate();
					
					Calendar calendar=Calendar.getInstance();
					java.sql.Date todaydate= new java.sql.Date(calendar.getTime().getTime());
					st=conn.prepareStatement("insert into bikeonrent values(?,?,?,?,?,?,?,?,?,?)");
					st.setDate(1, todaydate);
					st.setString(2, textUserName.getText());
					st.setString(3, textAddress.getText());
					st.setString(4, ""+textPhone.getText());
					st.setString(5, textMail.getText());
					st.setString(6, textName.getText());
					st.setString(7, textNumber.getText());
					st.setString(8, textCharges.getText());
					st.setString(9, textHour.getText());
					st.setInt(10, grandtotal);
					st.executeUpdate();
					
					st=conn.prepareStatement("update bike set status=0 where name='"+textName.getText()+"' and number='"+textNumber.getText()+"'");
					st.executeUpdate();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
				SendEmail.sendemail(textUserName.getText(),textName.getText(),textNumber.getText(),exphour,chrgs,total,security,grandtotal,textMail.getText());
				panel2.setVisible(false);
				panel1.setVisible(true);
				textUserName.setText("");
				textAddress.setText("");
				textMail.setText("");
				textPhone.setText("");
				
			}
			else
				JOptionPane.showMessageDialog(null, "enter correct expected hours");
			
			loadavailablebike();
			}
			
		});
		btnBook.setBounds(263, 318, 97, 29);
		panel2.add(btnBook);
		
		
		cmb1.setBounds(112, 72, 184, 29);
		panel2.add(cmb1);
		
		JLabel label_2 = new JLabel("");
		java.awt.Image imglogo4=new ImageIcon(this.getClass().getResource("/logo.jpg")).getImage();
		label_2.setIcon(new ImageIcon(imglogo4));
		label_2.setBounds(44, 11, 254, 103);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("");
		java.awt.Image imglogo13=new ImageIcon(this.getClass().getResource("/adminmain1.jpg")).getImage();
		label_3.setIcon(new ImageIcon(imglogo13));
		label_3.setBounds(679, 180, 335, 401);
		contentPane.add(label_3);
		
		JLabel lblChangePassword = new JLabel("Change Password");
		lblChangePassword.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
				dispose();
				ChangePassword cp=new ChangePassword();
			cp.setVisible(true);
			cp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				lblChangePassword.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			}
		});
		lblChangePassword.setForeground(new Color(0, 0, 204));
		lblChangePassword.setFont(new Font("Tahoma", Font.ITALIC, 16));
		lblChangePassword.setBounds(859, 131, 151, 20);
		contentPane.add(lblChangePassword);
		
		
	
	}
}
