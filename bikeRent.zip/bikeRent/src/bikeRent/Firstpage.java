package bikeRent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Firstpage {

	public static void main(String[] args) {
		int n=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","root");
				Statement st = conn.createStatement();
				ResultSet rs=st.executeQuery("select * from admintable");
				while(rs.next())
					n++;
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null, "Cant connect to database");
		}
		if(n==0)
		{
			AdminRegistration ar=new AdminRegistration();
			ar.setVisible(true);
			
		}
		else
		{
			Front fr=new Front();
			fr.frame.setVisible(true);
		}
		}
	}


