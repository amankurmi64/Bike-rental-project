package bikeRent;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import java.awt.Color;

public class Addbike extends JFrame {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textNumber;
	private JTextField textName;
	private JTextField textCharges;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Addbike frame = new Addbike();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Addbike() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				AdminMain ad =new AdminMain();
				ad.setVisible(true);
			}
			@Override
			public void windowClosing(WindowEvent arg0) {
			
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 532, 296);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddNewBike = new JLabel("Add New Bike...");
		lblAddNewBike.setForeground(Color.BLUE);
		lblAddNewBike.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAddNewBike.setBounds(37, 11, 142, 20);
		contentPane.add(lblAddNewBike);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblName.setBounds(37, 62, 52, 17);
		contentPane.add(lblName);
		
		JLabel lblNumber = new JLabel("Number:");
		lblNumber.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNumber.setBounds(25, 102, 63, 14);
		contentPane.add(lblNumber);
		
		JLabel lblCharges = new JLabel("Charges:");
		lblCharges.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCharges.setBounds(25, 158, 73, 17);
		contentPane.add(lblCharges);
		
		textNumber = new JTextField();
		textNumber.setBounds(98, 101, 160, 29);
		contentPane.add(textNumber);
		textNumber.setColumns(10);
		
		textName = new JTextField();
		textName.setBounds(99, 58, 159, 29);
		contentPane.add(textName);
		textName.setColumns(10);
		
		textCharges = new JTextField();
		textCharges.setBounds(98, 158, 131, 20);
		contentPane.add(textCharges);
		textCharges.setColumns(10);
		
		JButton btnAddBike = new JButton("Add Bike");
		btnAddBike.setBackground(new Color(153, 102, 255));
		btnAddBike.setForeground(Color.WHITE);
		btnAddBike.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnAddBike.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				String s1=textName.getText();
				String s2=textNumber.getText();
				String s3=textCharges.getText();
				Boolean b=false;
				Boolean c=false;
				
				
				
				if(s2.length()==8 && s1.length()!=0 && s3.length()!=0)
				{
					if(Character.isAlphabetic(s2.charAt(0)) && Character.isAlphabetic(s2.charAt(1)) && Character.isDigit(s2.charAt(4))
							&& Character.isDigit(s2.charAt(5)) && Character.isDigit(s2.charAt(6)) && Character.isDigit(s2.charAt(7))
							&& Character.isDigit(s2.charAt(2)) && Character.isDigit(s2.charAt(3)))
					{
						b=true;
					}
					for(int i=0;i<s3.length();i++)
					{
						if(Character.isAlphabetic(s3.charAt(i)))
						{
							c=false;
							break;
						}
						else
						{
							c=true;
						}
					}
				}
				
				if(b==true && c==true)
				{
				try
				{
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
				PreparedStatement st=conn.prepareStatement("insert into bike values(?,?,1,?)");
				st.setString(1, textName.getText());
				st.setString(2, textNumber.getText());
				st.setString(3, textCharges.getText());
				int i=st.executeUpdate();
					if(i!=0)
						JOptionPane.showMessageDialog(null, "Bike Entered into Reord Successfully");
					else
						JOptionPane.showMessageDialog(null, "Error into Entering Bike to Records ");
					
				textName.setText("");
				textNumber.setText("");
				textCharges.setText("");
				dispose();
				
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
				}
				else
					JOptionPane.showMessageDialog(null, "enter valid data");
			}
		});
		btnAddBike.setBounds(176, 208, 111, 29);
		contentPane.add(btnAddBike);
		
		JLabel lblRskm = new JLabel("Rs./hr");
		lblRskm.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblRskm.setBounds(241, 161, 46, 14);
		contentPane.add(lblRskm);
		
		JLabel label = new JLabel("");
		java.awt.Image imglogo5=new ImageIcon(this.getClass().getResource("/addbik.png")).getImage();
		label.setIcon(new ImageIcon(imglogo5));
		label.setBounds(327, 40, 142, 128);
		contentPane.add(label);
	}
}
