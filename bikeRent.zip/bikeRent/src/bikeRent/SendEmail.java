package bikeRent;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

public class SendEmail {

	public static void sendemail(String uname,String bikename,String bikenumber,int exphour,int chrgs,int total,int security,int gtotal,String email)
	{
    	final String username = "lokesh27ojha@gmail.com";
		final String password = "lokesh007";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {
			
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("lokesh27ojha@gmail.com"));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(email));
			
			message.setSubject("GiveMe Bike Services");
			message.setText("\nHi! "+uname+"\n\nYou booked Bike: "+bikename+
					"\nBike Number: "+bikenumber+"\nFor Hour(s): "+exphour+
					"\nCharge per Hour: "+chrgs+"\n\nTotal Amount: "+total+
					"\nSecurity amount: "+security+"\nTotal payable amount: "+gtotal+
					"\n\nThanks for giving us chance to serve You!");
			
			Transport.send(message);
			
			
			  JOptionPane.showMessageDialog(null,"Email has been sent");
			 
		} catch (MessagingException e) {
			          

			System.out.println(e);
		}
	}
}