package bikeRent;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPasswordField;

public class PasswordChange extends JFrame {

	private JPanel contentPane;
	private JTextField textUserName;
	private JTextField textAnswer;
	private JPasswordField textNewPass;
	private JPasswordField textConfirmNewPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PasswordChange frame = new PasswordChange();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PasswordChange() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
			
			Front fr=new Front();
			fr.frame.setVisible(true);
			
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 574, 414);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblChangePassword = new JLabel("Forgot Password...");
		lblChangePassword.setForeground(Color.BLUE);
		lblChangePassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangePassword.setBounds(27, 25, 191, 25);
		contentPane.add(lblChangePassword);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(new Color(255, 255, 255));
		panel1.setBounds(27, 61, 334, 296);
		contentPane.add(panel1);
		panel1.setLayout(null);
		
		JPanel panel2 = new JPanel();
		panel2.setBounds(27, 61, 334, 296);
		contentPane.add(panel2);
		panel2.setBackground(new Color(255, 255, 255));
		panel2.setLayout(null);
		panel2.setVisible(false);
		
		
		textUserName = new JTextField();
		textUserName.setBounds(149, 29, 146, 20);
		panel1.add(textUserName);
		textUserName.setColumns(10);
		
		JLabel lblUsername = new JLabel("UserName:");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUsername.setBounds(57, 28, 89, 19);
		panel1.add(lblUsername);
		
		JLabel lblQuestion = new JLabel("Question");
		lblQuestion.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblQuestion.setBounds(10, 143, 314, 20);
		panel1.add(lblQuestion);
		
		JLabel lblSecurityQuestion = new JLabel("Security Question:");
		lblSecurityQuestion.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSecurityQuestion.setBounds(10, 64, 136, 20);
		panel1.add(lblSecurityQuestion);
		
		textAnswer = new JTextField();
		textAnswer.setBounds(89, 182, 187, 29);
		panel1.add(textAnswer);
		textAnswer.setColumns(10);
		
		JLabel lblAnswer = new JLabel("Answer:");
		lblAnswer.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAnswer.setBounds(20, 183, 59, 14);
		panel1.add(lblAnswer);
		
		
		
		JButton btnCheck_1 = new JButton("Check");
		btnCheck_1.setBackground(new Color(153, 102, 255));
		btnCheck_1.setForeground(Color.WHITE);
		btnCheck_1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnCheck_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
						Statement st = conn.createStatement();
						ResultSet rs=st.executeQuery("select username,securityquestion from admintable where username='"+textUserName.getText()+"'");
						rs.next();
						if(rs.getString(1).equals(textUserName.getText()))
						{
							lblQuestion.setText(rs.getString(2));
						}
			
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, "No user found of this Username");
				}
			
			
			
			}
		});
		btnCheck_1.setBounds(186, 98, 109, 29);
		panel1.add(btnCheck_1);
		
		
		JButton btnCheck = new JButton("Continue");
		btnCheck.setForeground(new Color(255, 255, 255));
		btnCheck.setBackground(new Color(153, 102, 255));
		btnCheck.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				if(textAnswer.getText().length()!=0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
						Statement st = conn.createStatement();
						ResultSet rs=st.executeQuery("select answer from admintable where username='"+textUserName.getText()+"'");
						rs.next();
						
						if(rs.getString(1).equals(textAnswer.getText())) {
							panel1.setVisible(false);
							panel2.setVisible(true);
						}
						else
							JOptionPane.showMessageDialog(null, "Security answer didnt mathed");
						
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, "Security answer not matched");
				}
				}
				else
					JOptionPane.showMessageDialog(null, "enter security answer");
				
				
			}
		});
		btnCheck.setBounds(188, 241, 119, 29);
		panel1.add(btnCheck);
		
		JLabel label = new JLabel("");
		java.awt.Image imglogo=new ImageIcon(this.getClass().getResource("/forgotpass.png")).getImage();
		label.setIcon(new ImageIcon(imglogo));
		label.setBounds(401, 115, 138, 175);
		contentPane.add(label);
		
		
		
		
		JLabel lblNewPassword = new JLabel("New Password:");
		lblNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewPassword.setBounds(38, 93, 114, 14);
		panel2.add(lblNewPassword);
		
		JLabel lblConfirmNewPassword = new JLabel("Confirm New Password:");
		lblConfirmNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblConfirmNewPassword.setBounds(10, 138, 181, 14);
		panel2.add(lblConfirmNewPassword);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.setBackground(new Color(153, 102, 255));
		btnChangePassword.setForeground(new Color(255, 255, 255));
		btnChangePassword.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				if(textNewPass.getText().length()>=4 && textConfirmNewPass.getText().length()>=4) {
				if(textNewPass.getText().equals(textConfirmNewPass.getText()))
				{
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","");
					PreparedStatement st = conn.prepareStatement("update admintable set password='"+textConfirmNewPass.getText()+"' where username='"+textUserName.getText()+"'");
					int i=st.executeUpdate();
					if(i!=0)
					{
						JOptionPane.showMessageDialog(null, "Password successfully changed");
						dispose();
						
					}
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, "error into changing password");
				}
				}
				else
					JOptionPane.showMessageDialog(null, "Password Didn't matched");
				}
				else
					JOptionPane.showMessageDialog(null, "enter new password");
			}
		});
		btnChangePassword.setBounds(112, 192, 201, 28);
		panel2.add(btnChangePassword);
		
		textNewPass = new JPasswordField();
		textNewPass.setBounds(157, 92, 124, 20);
		panel2.add(textNewPass);
		
		textConfirmNewPass = new JPasswordField();
		textConfirmNewPass.setBounds(190, 137, 123, 20);
		panel2.add(textConfirmNewPass);
		
		
		
	}
}
