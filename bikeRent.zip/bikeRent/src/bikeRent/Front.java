package bikeRent;

import java.awt.EventQueue;


import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Front extends javax.swing.JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame frame;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Front window = new Front();
					window.setExtendedState(JFrame.MAXIMIZED_BOTH);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Front() {
		try {
			initialize();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setType(Type.POPUP);
		frame.setForeground(Color.RED);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100, 100, 787, 585);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	
		java.awt.Image img1=new ImageIcon(this.getClass().getResource("/ok1.png")).getImage();
		java.awt.Image img2=new ImageIcon(this.getClass().getResource("/log.png")).getImage();
		
		JPanel panel = new JPanel();
		panel.setVisible(true);
		panel.setBackground(Color.WHITE);
		panel.setBounds(482, 0, 296, 554);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblLogin = new JLabel("");
		lblLogin.setBounds(74, 124, 132, 138);
		panel.add(lblLogin);
		lblLogin.setIcon(new ImageIcon(img2));
		
		JLabel lblUsername = new JLabel("UserName:");
		lblUsername.setBounds(43, 305, 91, 14);
		panel.add(lblUsername);
		lblUsername.setFont(new Font("Tunga", Font.PLAIN, 20));
		
		txtUsername = new JTextField();
		txtUsername.setBounds(43, 330, 191, 29);
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(43, 388, 132, 14);
		panel.add(lblPassword);
		lblPassword.setFont(new Font("Tunga", Font.PLAIN, 20));
		
		txtPassword = new JPasswordField();
		txtPassword.setEchoChar('*');
		txtPassword.setBounds(43, 413, 191, 29);
		panel.add(txtPassword);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.setBackground(new Color(102, 102, 255));
		btnLogin.setBounds(62, 469, 155, 29);
		panel.add(btnLogin);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bikerent","root","root");
						Statement st = conn.createStatement();
						ResultSet rs=st.executeQuery("select username,password from admintable");
						rs.next();
						
						String s1=rs.getString(1);
						String s2=rs.getString(2);
						String i1=txtUsername.getText();
						String i2=txtPassword.getText();
						if(s1.equals(i1))
						{
							if(s2.equals(i2))
							{
			
								frame.dispose();
								AdminMain adm=new AdminMain();
								adm.setVisible(true);
								
								
							}
							else
								JOptionPane.showMessageDialog(null, "Check your Password");
						}
						else
							JOptionPane.showMessageDialog(null, "Check your Username");
					
						
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, "Cant connect to database");
				}
				
				
			
			}
		});
		btnLogin.setIcon(new ImageIcon(img1));
		
		JLabel label_1 = new JLabel("");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		java.awt.Image imglogo=new ImageIcon(this.getClass().getResource("/logo.jpg")).getImage();
		label_1.setIcon(new ImageIcon(imglogo));
		label_1.setBounds(10, 11, 264, 88);
		panel.add(label_1);
		
		JLabel lblForgotchangePassword = new JLabel("Forgot Password");
		lblForgotchangePassword.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			frame.dispose();
			PasswordChange pc=new PasswordChange();
			pc.setVisible(true);
			pc.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				lblForgotchangePassword.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			}
		});
		lblForgotchangePassword.setForeground(Color.BLUE);
		lblForgotchangePassword.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblForgotchangePassword.setBounds(127, 509, 136, 14);
		panel.add(lblForgotchangePassword);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 483, 554);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		java.awt.Image img3=new ImageIcon(this.getClass().getResource("/frontpagefinal.jpg")).getImage();
		label.setIcon(new ImageIcon(img3));
		label.setBounds(0, 0, 482, 553);
		panel_1.add(label);
	}
}
